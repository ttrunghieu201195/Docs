#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct leaf{
	char data[16];
	struct leaf *next;
};

struct leaf *addLeaf(char*, struct leaf*);
void printLeaves(struct leaf *p);
void freeLeaves(struct leaf *p);
struct leaf *insertLeaf(char *data, int position, struct leaf*);
struct leaf *removeLeaf(int, struct leaf*);

int main(void)
{
	struct leaf *top;
	char *fruits[3] = {"apple", "orange", "banana"};
	top = NULL;
	top = addLeaf(fruits[0], top);
	top = addLeaf(fruits[1], top);
	top = addLeaf(fruits[2], top);
	printf("Current fruit list: ");
	printLeaves(top);
	printf("------\n");
	char name[16];
	printf("Enter fruit name: ");
	scanf("%s",&name);
	printf("\n");
	int position;
	printf("Enter position insert: ");
	scanf("%d",&position);
	top = insertLeaf(name, position, top);
	printf("Fruit list after inserting %s at position %d\n",&name, position);
	printLeaves(top);
	bool invalid = true;
	do
	{
		char term;
		printf("Enter position to remove\n");
		if(scanf("%d%c", &position, &term) != 2 || term != '\n')
		{
			invalid = false;
		}
	}while(invalid);
	
	top = removeLeaf(position, top);

	printLeaves(top);

	freeLeaves(top);
}

void printLeaves(struct leaf *pL)
{
	while(pL != NULL){
		printf("%s\n", pL->data);
		pL = pL->next;
	}
}

struct leaf *addLeaf(char *data, struct leaf *top)
{
	struct leaf *pL;

	pL = (struct leaf*)malloc(sizeof(struct leaf));
	strcpy(pL->data, data);

	pL->next = top;
	top = pL;
	return top;
}

void freeLeaves(struct leaf *pL)
{
	struct leaf *pLnext;

	while(pL != NULL){
		pLnext = pL->next;
		free(pL);
		pL = pLnext;
	}
}

struct leaf *getElement(struct leaf *top, int position)
{
	struct leaf *pL = top;
	int count = 0;

	while(pL != NULL)
	{
		if(count == position-1)
		{
			break;
		}
		count++;
		pL = pL->next;
	}
	return pL;
}

struct leaf *getLastElement(struct leaf *top)
{
	while(top->next != NULL)
	{
		top = top->next;
	}
	return top;
}

int getCountFruit(struct leaf *top)
{
	int count = 0;
	while(top != NULL)
	{
		top = top->next;
		count++;
	}
	return count;
}

struct leaf *insertLeaf(char *data, int position, struct leaf* top)
{
	struct leaf *pL;

	pL = (struct leaf*)malloc(sizeof(struct leaf));
	strcpy(pL->data, data);
	if(position <= 1)
	{
		pL->next = top;
		top = pL;
	}
	else 
	{
		struct leaf *temp = getElement(top, position);
		if(temp != NULL)
		{
			pL->next = getElement(top, position);
			getElement(top, position-1)->next = pL;
		}
		else
		{
			pL->next = NULL;
			getLastElement(top)->next = pL;
		}
	}

	return top;
}

struct leaf *removeLeaf(int position, struct leaf *top)
{
	if(position < 1 || position > getCountFruit(top))
	{
		printf("Out of fruit list range\n");
	}
	else
	{
		struct leaf *temp = getElement(top, position);
		if(position == 1)
		{
			top = getElement(top, position+1);
			free(temp);
		}
		else if (position == getCountFruit(top))
		{
			getElement(top, position-1)->next = NULL;
			free(temp);
		}
		else
		{
			getElement(top, position-1)->next = getElement(top, position+1);
			free(temp);
		}	
	}
	return top;
}