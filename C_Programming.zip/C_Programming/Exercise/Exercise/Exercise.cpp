// Exercise.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


int _tmain(int argc, _TCHAR* argv[])
{
	return 0;
}

void main()
{
	char data01[] = "Hello world";
	char *pData;
	printf("%s\n", data01);
}