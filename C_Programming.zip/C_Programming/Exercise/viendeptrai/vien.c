#include <stdio.h>
void main(){
	printf("vien dep trai");
}