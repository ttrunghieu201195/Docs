#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct leaf{
	char data[16];
	struct leaf * next;
};
struct leaf * createLeaf(char * str);
void addHead(struct leaf * &root, struct leaf *node);
void addTail(struct leaf * &root, struct leaf *node);
void addPos(struct leaf * &root, struct leaf *node, int pos);
void removePos(struct leaf * &root, int pos);
void freeLeaves(struct leaf * &root);
void printLeaves(struct leaf * root);
void initial(leaf * &root);
void insert_element_cherry(leaf * &root);
void exer_4_1(leaf * &root);
void exer_4_2(leaf * &root);
void exer_4_1_op(leaf * &root);
void exer_4_2_op(leaf * &root);