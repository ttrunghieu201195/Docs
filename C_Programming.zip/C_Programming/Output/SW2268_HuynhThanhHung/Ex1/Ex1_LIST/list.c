#include "list.h"

struct leaf * createLeaf(char * str)
{
	struct leaf *node = (struct leaf *)(malloc(sizeof(struct leaf)));
	strcpy(node->data,str);
	node->next = NULL;
	return node;
}

void addHead(struct leaf * &root, struct leaf *node)
{
	if (root == NULL)
	{
		root = node;
	}
	else
	{
		node->next = root;
		root = node;
	}
}
void addTail(struct leaf * &root, struct leaf *node)
{
	struct leaf * temp = root;
	while (temp != NULL)
	{
		if (temp->next == NULL)
		{
			temp->next = node;
			break;
		}
		else
		{
			temp = temp->next;
		}
	}
}
void addPos(struct leaf * &root, struct leaf *node, int pos)
{
	struct leaf *temp = root;
	int i = 0;
	if (pos < 0)
		return ;
	if (pos == 0 || root == NULL)
	{
		addHead(root, node);
	}
	else
	{
		while (temp != NULL)
		{
			if (temp->next == NULL && i < pos)
			{
				addTail(root, node);
				break;
			}
			else
			{
				if (i == pos - 1)
				{ 
					node->next = temp->next;
					temp->next = node;
					break;
				}
				temp = temp->next;
				i++;
			}
		}
	}
}

void removePos(struct leaf * &root, int pos)
{
	struct leaf *temp = root;
	int i = 0;
	if (root == NULL)											//Check if leaves have leaf
	{
		return;
	}
	if (pos == 0)												//Pos is the root of leaves
	{
		root = temp->next;										//Set root is the next leaf
		free(temp);												//Free pos position
	}
	else
	{
		while (temp != NULL)
		{

			if (i == pos - 1)									//Before position will be deleted 1 position
			{
				if (temp->next != NULL)							//Check if position will be deleted is NULL or not
				{
					struct leaf * node = temp->next;
					temp->next = temp->next->next;				//Set the (pos)th in the future is (pos+1)th in the current
					free(node);
					break;
				}
				else
				{
					break;										//If at pos position null, then do nothing
				}
			}
			i++;												//Incresement self-define flag
			temp = temp->next;									//Set pointer to the next position
		}
	}
}

void freeLeaves(struct leaf * &root)
{
	while (root != NULL)
	{
		removePos(root, 0);
	}
	free(root);
}
void printLeaves(struct leaf * root)
{
	struct leaf * temp = root;

	while (temp != NULL)
	{
		printf("%s \n", temp->data);
		temp = temp->next;
	}
	printf("--------------------\n");
}

void initial(leaf* &root)
{
	root = (struct leaf*)malloc(sizeof(struct leaf));
	root = NULL;
	struct  leaf * node;
	node = createLeaf("apple");
	addHead(root, node);
	node = createLeaf("orange");
	addHead(root, node);
	node = createLeaf("banana");
	addHead(root, node);
}

void insert_element_cherry(leaf * &root)
{
	printf("Insert element cherry after element 1th \n");
	struct leaf* node = createLeaf("cherry");
	addPos(root, node,1);
	printLeaves(root);
}
void exer_4_1(leaf * &root)
{
	printf("Exercise 4-1: insert 'grape' after element 1th \n");
	struct leaf* node = createLeaf("grape");
	addPos(root, node, 1);
	printLeaves(root);
}
void exer_4_2(leaf * &root)
{
	printf("Exercise 4-2: remove element 2th \n");
	removePos(root, 1);
	printLeaves(root);
}

void exer_4_1_op(leaf * &root)
{
	char data[20];
	int pos;
	printf("Exercise 4-1 Optinal: Input data then insert \n");
	printf("Input data: ");
	fflush(stdin);
	gets(data);
	struct leaf * node = createLeaf(data);
	addTail(root, node);
	printLeaves(root);
	printf("Exercise 4-1 Optinal: Input data then insert to position\n");
	printf("Input data: ");
	fflush(stdin);
	gets(data);
	printf("Input position: ");
	scanf("%d", &pos);
	node = createLeaf(data);
	addPos(root, node, pos);
	printLeaves(root);
}
void exer_4_2_op(leaf * &root)
{
	int pos;
	printf("Exercise 4-2 Optinal: Input position and remove that position \n");
	printf("Input position: ");
	scanf("%d", &pos);
	removePos(root, pos);
	printLeaves(root);
}