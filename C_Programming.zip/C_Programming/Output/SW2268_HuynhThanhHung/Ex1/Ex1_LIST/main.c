#include "list.h"
int main()
{
	struct leaf* leafRoot;
	initial(leafRoot);
	printLeaves(leafRoot);
	insert_element_cherry(leafRoot);
	printLeaves(leafRoot);
	freeLeaves(leafRoot);

	initial(leafRoot);
	exer_4_1(leafRoot);
	freeLeaves(leafRoot);
	initial(leafRoot);
	exer_4_2(leafRoot);
	freeLeaves(leafRoot);
	
	initial(leafRoot);
	exer_4_1_op(leafRoot);
	exer_4_2_op(leafRoot);
	
	return 0;
}