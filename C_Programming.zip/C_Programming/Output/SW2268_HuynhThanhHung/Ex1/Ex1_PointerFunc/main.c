#include <stdio.h>
#include <stdlib.h>

double fraction(int);
double quare(int);
double complex(int type, int num);
double complex2(int num, double(**pF)(int));
double divide(double(**f1)(int), double(**f2)(int), int num);
double (*func[2])(int) = { fraction, quare };

double fraction(int num)					
{
	return 1.0 / num;
}
double quare(int num)						
{
	return num*num;
}

double complex(int type,int num)	
{
	if (num == 1||num == 0)
		return num;	
	return func[type](num)+complex(type,num-1);
}
double complex2(int num, double(**pF)(int))
{
	if (num == 1 || num == 0)
		return num;
	return (*pF)(num)+complex2(num - 1, pF);
}

double divide(double (**f1)(int), double (**f2)(int),int num)
{
	return complex2(num, f1) / complex2(num, f2);
}

int main()
{
	int i,type;
	printf("0) Fraction calculator: 1/(n) + 1/(n-1) +..+ 1/1 \n");
	printf("1) Quare calculator:    (n)^2 + (n-1)^2 +..+ 1 \n");
	printf("Input type to process: ");
	scanf("%d", &type);
	printf("Input number: ");
	scanf("%d", &i);
	printf("Value: %lf \n", complex(type, i));
	printf("Value Func[0]/Func[1] with Number %d = %lf \n", i, divide(&func[0], &func[1], i));
	printf("Value Func[1]/Func[0] with Number %d = %lf \n", i, divide(&func[1], &func[0], i));
	return 0;
}