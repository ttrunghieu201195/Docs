#ifndef __GUESS_NUM_H__
#define __GUESS_NUM_H__

#include <stdio.h>
#include <conio.h>

#define MAX_LEN 4

int isMatch(char target[], char number[]);
int isValidNumber(char num[]);
void createRandomNumber(char num[]);
void inputTarget(char target[]);
#endif