
#include "GuessNumber.h"

int main()
{
	char num[20],target[20];
	createRandomNumber(num);
	do{
		inputTarget(target);
	} while (isMatch(target, num) == 0);
	printf("Good \n");
	system("pause");
	return 0;
}