#include "GuessNumber.h"
#ifdef  __GUESS_NUM_H__
#ifndef __GUESS_NUM_C__
#define __GUESS_NUM_C__

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
int isMatch(char target[], char number[])	//Check if the player's number match with game's number
{
	int i,j,hit,blow;
	i = 0;
	hit = blow = 0;	
	while (target[i] != '\0')					//Check per position of player's number match with game's number
	{
		j = 0;									//Set position of game's number is first
		while (number[j] != '\0')				//Scan the j position of target's number to each of position of game's number
		{
			if (number[j] == target[i])			//If target[i] match with number[i], then player's number has this number
			{
				if (i == j)						//If position of target's number equal  position of game's number, it's hit
				{
					hit++;
				}
				else								//Otherwise, it's blow
				{
					blow++;
				}
			}
			
			j++;								//Increase position of number
		}
		i++;									//Increase position of target to check hit,blow
	}
	printf("%d Hit. %d Blow \n", hit, blow);
	if (hit == i)								//If number of hit equal to length of target's number, so it's all hit, it's match with game's number
		return 1;								//Number of i is a length of the game's requirement
	else
		return 0;
}
int isValidNumber(char num[])		//Check if number is valid
{
	int i;
	i = 0;
	while (num[i] != '\0')
	{
		if (i >= MAX_LEN || num[i] <48 || num[i] > 57 || num[0] == '0')			// Prevent num is '0xxx' | '![0-9] >> xxxx' | length of num over request
			return 0;
		int j = i + 1;
		while (num[j] != '\0')			
		{
			if (num[j] == num[i])												// Prevent duplicate number
				return 0;
			j++;
		}
		i++;
	}
	if (i != (MAX_LEN))
		return 0;
	return 1;
}
void createRandomNumber(char num[])		//Create random number
{
	int i;
	int num_rand;
	char temp;
	srand(time(NULL));
	do{
		num_rand = (int)rand();													//Create random number
		i = 0;
		while (i<MAX_LEN)
		{
			num[MAX_LEN-i-1] = (num_rand % 10) + 48;							//Get the last position of random_number to the i position of num[]
			num_rand = num_rand / 10;											//Change to next position by divide random_number to 10
			i++;																			
		}
		num[i] = '\0';
	} while (isValidNumber(num) == 0);											//Check the number is valid or not
}

void inputTarget(char target[])		//interface input number of player
{
	do{
		printf("Input target number: ");
		fflush(stdin);
		gets(target);
	} while (isValidNumber(target)==0);											//Require the player input number is valid
	
}
#endif
#endif