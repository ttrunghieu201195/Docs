#include "GuessNumber.h"

int main()
{
	char target[5];
	char num[5];
	char c;

	do
	{
		createRandomNumber(target);
		fflush(stdin);
		do
		{
			printf("Your guess number: ");
			gets(num);
			if (!isValidNumber(num))
			{
				printf("Have number indentical! Please try again!\n");
				continue;
			}
			if (isMatch(target, num))
			{
				printf("You Won!\n");
				break;
			}
		} while (1);

		printf("Do you want play again?(y/n): ");

		scanf("%c", &c);
		if (c != 'y' && c != 'Y')
			break;
	} while (1);

	return 0;
}