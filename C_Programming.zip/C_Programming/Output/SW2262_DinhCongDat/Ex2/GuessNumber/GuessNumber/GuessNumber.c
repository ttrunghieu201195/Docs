#include "GuessNumber.h"

int isMatch(char target[], char num[])
{
	int hit = 0, blow = 0, i, j, k;
	if (strcmp(target, num) == 0)
		return 1;
	else
	{
		for (i = 0; i < 4; i++)
		{
			if (target[i] == num[i])
			{
				hit++;
			}
		}

		for (j = 0; j < 4; j++)
		{
			for (k = 0; k < 4; k++)
			{
				if (target[j] == num[k])
				{
					blow++;
				}
			}
		}
	}

	printf("Hit: %d		Blow: %d\n", hit, blow - hit);
	return 0;
}

int isValidNumber(char num[])
{
	int i, j;

	for (i = 0; i < 4; i++)
	{
		if (num[i] < 48 || num[i] > 57)
		{
			return 0;
		}
	}

	if (strlen(num) > 4 || strlen(num) < 4)
	{
		return 0;
	}
	else
	{
		for (i = 0; i < 3; i++)
		{
			for (j = i + 1; j < 4; j++)
			{
				if (num[i] == num[j])
				{
					return 0;
				}
			}
		}
	}

	return 1;
}

void createRandomNumber(char num[])
{
	int i;

	srand(time(NULL));

	while (1)
	{
		i = 0;
		while (i < 4)
		{
			num[i] = (rand() % 9) + 48;
			i++;
		}
		num[4] = '\0';
		if (isValidNumber(num))
		{
			break;
		}
	}
	//printf("%s\n", num);
}

