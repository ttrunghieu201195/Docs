#include <stdio.h>
#include <string.h>
#include <time.h>

int isMatch(char target[], char num[]);
int isValidNumber(char num[]);
void createRandomNumber(char num[]);