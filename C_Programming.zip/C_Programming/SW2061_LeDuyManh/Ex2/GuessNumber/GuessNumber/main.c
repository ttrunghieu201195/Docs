#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "Debug.h"

#define TRUE (0)
#define FALSE (1)

int isMatch(char target[], char num[])
{
	int hit = 0, blow = 0;
	int i, j;
	for (i = 0; i < 4; i++)
	{
		if (target[i] == num[i])
		{
			hit++;
		}
		for (j = 0; j < 4; j++)
		{
			if (j != i && target[i] == num[j])
			{
				blow++;
			}
		}
	}
	printf("\n%d Hit,",hit);
	printf("%d Blow",blow);
	if (hit == 4)
	{
		printf("\tGood!");
		return TRUE;
	}
	return FALSE;
}

int isValidNumber(char num[])
{
	int i, j;
	if (num[4] != '\0')
	{
		return FALSE;
	}
	for (i = 0; i < 3; i++)
	{
		for (j = i + 1 ; j < 4; j++)
		{
			if (num[i] == num[j])
			{
				return FALSE;
			}
		}
	}
	return TRUE;
}

void createRandomNumber(char num[])
{
	int i;
	srand(time(NULL));
	for (i = 0; i < 4; i++)
	{
		num[i]= (char)(rand()%10+48);
	}
	num[4] = '\0';
}

int main(int argc, char * argv[])
{
	char target[5], num[5];
	do {
		createRandomNumber(target);
	} while (isValidNumber(target) == FALSE);

#ifdef _DEBUG_PROG
	if (argc == 2 && strcmp(argv[1], "-debug") == TRUE)
	{
		printf("\nCreate number %s",target);
	}
#endif

	do {
		printf("\nGuess number: ");
		scanf("%s",num);
	} while (isValidNumber(num) == FALSE || isMatch(target, num) == FALSE);

	return 0;
}