package _JavaReadLine;

import java.io.File;
import java.io.IOException;

public class readLine {
	static long pointer;

	public static void main(String[] args) {
		File file = new File("input.txt");
		long length = file.length();
		for (long i = 0; i < ((length / 5) + 1); i++) {
			String str = readlines(file, 5);
			System.out.println(str);
			System.out.println("\n");
		}
	}

	public static String readlines(File file, int lines) {
		java.io.RandomAccessFile fileHandler = null;
		try {
			fileHandler = new java.io.RandomAccessFile(file, "r");
			long fileLength = fileHandler.length() - 1;
			StringBuilder sb = new StringBuilder();
			int line = 0;
			long temp = pointer;

			for (long filePointer = temp; filePointer <= fileLength; filePointer++) {
				fileHandler.seek(filePointer);
				int readByte = fileHandler.readByte();

				if (readByte == 0xA) { // (char)0xA = \n
					if (filePointer < fileLength) {
						line = (line + 1);
					}
				}
				pointer = filePointer+1;
				if (line >= lines) {
	                break;
	            }

				sb.append((char) readByte);
			}
			return sb.toString();
		} catch (java.io.FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (java.io.IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			if (fileHandler != null)
				try {
					fileHandler.close();
				} catch (IOException e) {
				}
		}
	}

}
