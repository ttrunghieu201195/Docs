package testSomething;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class testSomething {

	public static void main(String[] args) throws IOException {
//		try {
//			OutputStream out = new FileOutputStream("D:/data.csv");
//			for(long i = 0,j = 0; i <= 2000000000; i+=20,j+=2) {
//				try {
//					out.write((i+" "+j).getBytes());
//					out.write("\r\n".getBytes());
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}
		//-------------------------------
//		try {
//				OutputStream out = new FileOutputStream("D:/random.txt");
//				for(int i = 0; i< 722035; i++) {
//					Random rd = new Random();
//					
//					String a = String.valueOf(rd.nextInt(722035));
//					try {
//						out.write(a.getBytes());
//						out.write("\r\n".getBytes());
//					} catch (IOException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//				}
//			} catch (FileNotFoundException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
		 try {
		      
	         // create a new RandomAccessFile with filename test
	         File file = new File("D:/random.txt");
			 RandomAccessFile raf = new RandomAccessFile(file, "rw");
	         
	         
	         
	      } catch (IOException ex) {
	         ex.printStackTrace();
	      }
		
		
	}

}
