package testSomething;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

public class WriteFile {

	private static final int ITERATIONS = 5;
	private static final double MEG = (Math.pow(1024, 2));
	private static final int RECORD_COUNT = 4000000;
	private static final String RECORD = "Help I am trapped in a fortune cookie factory\n";
	private static final int RECSIZE = RECORD.getBytes().length;
	private static final int bufSize = 4 * (int) MEG;
	private static List<String> timestamps = new ArrayList<>();
	private static List<String> currents = new ArrayList<>();
	private static final int MILLIONS = 1000000;

	public static void main(String[] args) throws Exception {
		long start = System.currentTimeMillis();
		File file = new File("D:\\test.txt");
		Long count = (long) 600;
		split(file, count);
		long end = System.currentTimeMillis();
		System.out.println((end - start) / 1000f + " seconds");
	}

	// write data
	private static void writeBuffered(List<String> timestamps, List<String> currents, int bufSize, String name) throws IOException {
		File file = File.createTempFile(name, ".txt");
		try {
			FileWriter writer = new FileWriter(file);
			BufferedWriter bufferedWriter = new BufferedWriter(writer, bufSize);
			System.out.print("Writing buffered (buffer size: " + bufSize + ")... ");
			write(timestamps, currents, bufferedWriter);
		} finally {
			// comment this out if you want to inspect the files afterward
//			file.delete();
		}
	}

	private static void write(List<String> timestamps, List<String> currents, Writer writer) throws IOException {
		if(timestamps.size() == currents.size()) {
			for (int i = 0; i < timestamps.size(); i ++) {
				writer.write(timestamps.toArray()[i]+" "+currents.toArray()[i]);
			}
		}

		writer.flush();
		writer.close();
	}
	// read data
	private static void readBuffered(File file, int bufSize, Long count) throws IOException{
//		File file = new File("D:\\test.txt");

		if(file.exists()) {
			try(
				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr, bufSize);
				) {
				System.out.print("Reading buffered (buffer size: ) " + bufSize + ")..");
				read(br, timestamps, currents, count * MILLIONS);
			}
		}
		
	}
	
	private static void read(BufferedReader br, List<String> timestamps, List<String> currents, Long count) {
		try {
			String line = br.readLine();
			while((line != null && !"".equals(line))) {
				String tmp = line.substring(0, line.indexOf(" "));
				
				timestamps.add(tmp);
				currents.add(line.substring(line.indexOf(" ")+1));
				if(Long.parseLong(tmp) > count * 1000000) {
					break;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//split data
	static long pointer;
	private static void split(File file, Long count) {
		RandomAccessFile fileHandler = null;
		try {
			fileHandler = new RandomAccessFile(file, "r");
			Long fileLength = fileHandler.length() - 1;
			long temp = pointer;
			int i = 1;
			String line;
			for(long filePointer = temp; filePointer <= fileLength; filePointer++) {
				fileHandler.seek(filePointer);
				line = fileHandler.readLine();
				timestamps.add(line.substring(0, line.indexOf(" ")).trim());
				currents.add(line.substring(line.indexOf(" ")).trim());
				if(Long.parseLong(line.substring(0, line.indexOf(" ")).trim()) >= (count * MILLIONS *i)) {
					writeBuffered(timestamps, currents, bufSize, file.getName()+"_part"+i);
					i++;
					timestamps.clear();
					currents.clear();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}